# Übersicht Widget - CSC/USD price

Based on [Eugen Lofts XRP Widget] (https://github.com/eluft84/ubersicht-ripple-usd-price)

which is based on...

[Daniel Spillere Andrade BTC widget](https://github.com/felixhageloh/uebersicht-widgets/tree/master/btc). 
